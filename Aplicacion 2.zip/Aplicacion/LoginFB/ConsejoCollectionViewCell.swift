//
//  ConsejoCollectionViewCell.swift
//  LoginFB
//
//  Created by Cristian Lopez on 03/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//


import UIKit

class ConsejoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var etiqueta: UILabel!
}
