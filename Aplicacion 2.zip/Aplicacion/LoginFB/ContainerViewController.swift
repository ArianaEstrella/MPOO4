//
//  ContainerViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 04/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class ContainerViewController: UIViewController, UIPageViewControllerDataSource {
    var vieneDeVistaUno: String = ""
    var Preguntas = ["Pregunta 1", "Pregunta 2"]
    var Respuestas = [["Respuesta 1", "Respuesta 2", "Respuesta 3", "Respuesta 4"],["Respuesta 5", "Respuesta 6 ", "Respuesta 7", "Respuesta 8"]]
    var ref: DatabaseReference!
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let viewController = viewController as! ContenentViewController
        var index = viewController.pagesIndex
        if index == 0 {
            return nil
        }
        index -= 1
        return viewCotrollerAtIndex(index: index)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let viewController = viewController as! ContenentViewController
        var index = viewController.pagesIndex
        index += 1
        if index == Preguntas.count{
            return nil
        }
        return viewCotrollerAtIndex(index: index)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let pageController = self.storyboard?.instantiateViewController(withIdentifier: "pageViewController") as! UIPageViewController
        let startingViewController = viewCotrollerAtIndex(index: 0)!
        
        pageController.dataSource = self
        let viewControllers = [startingViewController]
        pageController.setViewControllers(viewControllers, direction: .forward, animated: true, completion: nil)
        pageController.view.frame = view.bounds
        self.addChild(pageController)
        self.view.addSubview(pageController.view)
        pageController.didMove(toParent: self)
        
        ref = Database.database().reference()
        let db = Firestore.firestore()
        let docRef = db.collection("Materias").document(vieneDeVistaUno)
        
        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
                guard let dictionary = document.data() as? [String: Any] else {return}
                guard let dictionaryArray = dictionary["preguntas"] as? [[String: String]] else {return}
                let answer = dictionaryArray.first!["b"]
                print("Document data: \(dataDescription)")
            } else {
                print("Document does not exist")
            }
        }
       
    

    }
    
    func viewCotrollerAtIndex(index: Int)-> ContenentViewController?{
        if index >= Preguntas.count {
            return nil
        }
        let contentViewController = self.storyboard?.instantiateViewController(withIdentifier: "contenentViewController") as! ContenentViewController
        contentViewController.text = Preguntas[index]
        contentViewController.abs = Respuestas[index]
        
        return contentViewController
    }
    



}
